import RootRoutes from "./pages/Layout/RootRoutes";
import "./css/style.css";
import "./css/notosanskr.css"

function App() {
  return <RootRoutes />;
}

export default App;
